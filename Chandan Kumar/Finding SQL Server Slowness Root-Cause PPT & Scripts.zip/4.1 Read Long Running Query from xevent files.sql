--getting long running query from ex ev file
declare @LongQryExEvFile_Path nvarchar(300) = 'C:\SQLPlanner_dir_Deadlock_detect\SQLPlanner_long_queries_4eec709375c04e6*.xel'
SELECT  top 100  CONVERT(XML, event_Data) as event_data  , 
CONVERT(XML, event_Data).value('(event/@timestamp)[1]', 'datetimeoffset') datetime2_GMT_TimeZone, 
CONVERT(XML, event_Data).value(N'(event/@name)[1]', N'nvarchar(100)') Event_name,
CONVERT(XML, event_Data).value(N'(event/action[@name="database_name"]/value)[1]', N'nvarchar(250)') _database_name,
CONVERT(XML, event_Data).value(N'(event/action[@name="sql_text"]/value)[1]', N'nvarchar(max)') sql_text,
CONVERT(XML, event_Data).value(N'(event/data[@name="cpu_time"]/value)[1]', N'bigint') cpu_time,
CONVERT(XML, event_Data).value(N'(event/data[@name="duration"]/value)[1]', 'bigint') duration,
CONVERT(XML, event_Data).value(N'(event/data[@name="physical_reads"]/value)[1]', 'bigint') physical_reads,
CONVERT(XML, event_Data).value(N'(event/data[@name="logical_reads"]/value)[1]', 'bigint') logical_reads,
CONVERT(XML, event_Data).value(N'(event/data[@name="writes"]/value)[1]', 'bigint') writes,
CONVERT(XML, event_Data).value(N'(event/data[@name="row_count"]/value)[1]', 'bigint') row_count,
CONVERT(XML, event_Data).value(N'(event/data[@name="object_name"]/value)[1]', N'nvarchar(1000)') _object_name,
CONVERT(XML, event_Data).value(N'(event/data[@name="object_type"]/value)[1]', N'nvarchar(1000)') _object_type,
CONVERT(XML, event_Data).value(N'(event/data[@name="statement"]/value)[1]', N'nvarchar(max)') _statement,
CONVERT(XML, event_Data).value(N'(event/action[@name="client_app_name"]/value)[1]', N'nvarchar(250)') client_app_name,
CONVERT(XML, event_Data).value(N'(event/action[@name="client_hostname"]/value)[1]', N'nvarchar(250)') client_hostname,
CONVERT(XML, event_Data).value(N'(event/action[@name="collect_system_time"]/value)[1]', N'nvarchar(250)') collect_system_time,

CONVERT(XML, event_Data).value(N'(event/action[@name="plan_handle"]/value)[1]', N'nvarchar(max)') plan_handle,
CONVERT(XML, event_Data).value(N'(event/action[@name="session_id"]/value)[1]', N'nvarchar(50)') session_id,
CONVERT(XML, event_Data).value(N'(event/action[@name="session_nt_username"]/value)[1]', N'nvarchar(100)') session_nt_username,

CONVERT(XML, event_Data).value(N'(event/action[@name="username"]/value)[1]', N'nvarchar(max)') username 
 
FROM sys.fn_xe_file_target_read_file
(@LongQryExEvFile_Path,NULL,NULL,NULL) T
 
 Order by 
 CONVERT(XML, event_Data).value(N'(event/data[@name="cpu_time"]/value)[1]', N'bigint') desc,
 CONVERT(XML, event_Data).value('(event/@timestamp)[1]', 'datetimeoffset') desc 