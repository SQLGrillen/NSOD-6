use [SQLPlanner]
--index scan in query plan simulator
select db_names,physical_name from [dbo].[Alert_DBSIZE] where [recovery_model_desc] = 'Simple'
go 3 
SELECT TOP 100000 [JobID]
      ,[Qry_event_name]
      ,[QueryCompletedEndDatetime]
      ,[QueryCompletedStartDatetime]
      ,[datetime2_GMT]
      ,[CPU_Time_Sec]
      ,[duration]
      ,[physical_reads]
      ,[logical_reads]
      ,[writes]
      ,[row_count]
      ,[_object_name]
      ,[_object_type]
      ,[_statement]
      ,[client_app_name]
      ,[client_hostname]
      ,[_database_name]
      ,[plan_handle]
      ,[session_id]
      ,[transaction_id]
      ,[session_nt_username]
      ,[sql_text]
      ,[username]
      ,[tsql_stack1]
      ,[tsql_stack2]
      ,[Dismiss]
      ,[AlertFound]
      ,[CreateDateTime]
  FROM [SQLPlanner].[dbo].[Alert_LongRunningQuery_Monitoring_ExEv] where Qry_event_name = 'sql_batch_completed'

use master
DBCC CHECKDB ('SQLPlanner')   
go 2

use master
BACKUP DATABASE [SQLPlanner] TO  DISK = N'E:\MyDotNetProjects\SQLPlanner_21-7-2023.bak' WITH NOFORMAT, NOINIT,  
NAME = N'SQLPlanner-Full Database Backup', SKIP, NOREWIND, NOUNLOAD,  STATS = 10
GO


