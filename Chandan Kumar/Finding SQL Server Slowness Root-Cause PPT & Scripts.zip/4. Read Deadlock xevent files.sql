--read data from xevent files


-- read deadlock data
declare @JobID uniqueidentifier = newid()
declare @file_Location nvarchar(100) = N'C:\SQLPlanner_dir_Deadlock_detect\SQLPlanner_Deadlock_detection_data*.xel'
select  SYSDATETIMEOFFSET() AS [Current_System_DateTime_Offset],   [object_name],cast(event_data as xml) event_data,[file_name] FROM sys.fn_xe_file_target_read_file(@file_Location, NULL, NULL, NULL)



SELECT   event_Data ,  
CONVERT(XML, event_Data).value('(event/data/value/deadlock/victim-list/victimProcess/@id)[1]','nvarchar(max)') ,--Victim_Process_ID
CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@id)[2]','nvarchar(max)') ,--Normal_Process_ID
 
'PROCESS_ID - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@id)[1]','nvarchar(max)'),'') + '*|-|-|*' +
'SPID - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@spid)[1]','nvarchar(max)'),'')  + '*|-|-|*' +
'WAIT_TIME (Millisecond)- '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@waittime)[1]','nvarchar(max)'),'') + '*|-|-|*' +  
'TRANSACTIONNAME - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@transactionname)[1]','nvarchar(max)'),'')  + '*|-|-|*' +
'LAST_TRAN_STARTED_DATETIME - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@lasttranstarted)[1]','nvarchar(max)'),'')  + '*|-|-|*' +
'LOCK_MODE - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@lockMode)[1]','nvarchar(max)'),'')  + '*|-|-|*' +
'STATUS - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@status)[1]','nvarchar(max)'),'')  + '*|-|-|*' +
'CLIENT_APP - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@clientapp)[1]','nvarchar(max)'),'')  + '*|-|-|*' +
'HOST_NAME - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@hostname)[1]','nvarchar(max)'),'')  + '*|-|-|*' +
'LOGIN_NAME - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@loginname)[1]','nvarchar(max)'),'')  + '*|-|-|*' +
'QUERY_DETAILS - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/inputbuf)[1]','nvarchar(max)'),'')  + '*|-|-|*' 
,--as ProcessID1_Details

'PROCESS_ID - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@id)[2]','nvarchar(max)'),'') + '*|-|-|*' +
'SPID - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@spid)[2]','nvarchar(max)'),'')  + '*|-|-|*' +
'WAIT_TIME (Millisecond)- '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@waittime)[2]','nvarchar(max)'),'') + '*|-|-|*' +  
'TRANSACTION_NAME - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@transactionname)[2]','nvarchar(max)'),'')  + '*|-|-|*' +
'LAST_TRAN_STARTED_DATETIME - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@lasttranstarted)[2]','nvarchar(max)'),'')  + '*|-|-|*' +
'LOCK_MODE - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@lockMode)[2]','nvarchar(max)'),'')  + '*|-|-|*' +
'STATUS - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@status)[2]','nvarchar(max)'),'')  + '*|-|-|*' +
'CLIENT_APP - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@clientapp)[2]','nvarchar(max)'),'')  + '*|-|-|*' +
'HOST_NAME - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@hostname)[2]','nvarchar(max)'),'')  + '*|-|-|*' +
'LOGIN_NAME - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/@loginname)[2]','nvarchar(max)'),'')  + '*|-|-|*' +
'QUERY_DETAILS - '+isnull(CONVERT(XML, event_Data).value('(event/data/value/deadlock/process-list/process/inputbuf)[2]','nvarchar(max)'),'')  + '*|-|-|*' 
,--as ProcessID2_Details

CONVERT(XML, event_Data).value('(event/data/value/deadlock/resource-list/ridlock/owner-list/owner/@id)[1]','nvarchar(max)') + '*|-|-|*' +
CONVERT(XML, event_Data).value('(event/data/value/deadlock/resource-list/ridlock/@objectname)[1]','nvarchar(max)'),-- ObjectName1,

CONVERT(XML, event_Data).value('(event/data/value/deadlock/resource-list/ridlock/owner-list/owner/@id)[2]','nvarchar(max)') + '*|-|-|*' +
CONVERT(XML, event_Data).value('(event/data/value/deadlock/resource-list/ridlock/@objectname)[2]','nvarchar(max)')-- ObjectName2 
  
FROM  sys.fn_xe_file_target_read_file(@file_Location, NULL, NULL, NULL)





--get blocked data
SELECT CAST(event_Data AS xml) AS event_data ,
CONVERT(XML, event_Data).value('(event/@timestamp)[1]', 'datetime2(0)') datetime2_,
CONVERT(XML, event_Data).value('(event/@name)[1]', 'varchar(50)') AS event_name_,

CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@id)[1]','nvarchar(max)') blocked_process_id_,  --- move to node value
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@waitresource)[1]','nvarchar(max)') blocked_process_waitresource,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@waittime)[1]','nvarchar(max)') Blocked_Process_waittime,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@transactionname)[1]','nvarchar(max)') Blocked_Process_transactionname,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@lasttranstarted)[1]','nvarchar(max)') Blocked_Process_lasttranstarted,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@lockMode)[1]','nvarchar(max)') Blocked_Process_lockMode,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@status)[1]','nvarchar(max)') Blocked_Process_status,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@spid)[1]','nvarchar(max)') Blocked_Process_spid,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@trancount)[1]','nvarchar(max)') Blocked_Process_trancount,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@lastbatchstarted)[1]','nvarchar(max)') Blocked_Process_lastbatchstarted,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@lastbatchcompleted)[1]','nvarchar(max)') Blocked_Process_lastbatchcompleted,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@hostname)[1]','nvarchar(max)') Blocked_Process_hostname,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@loginname)[1]','nvarchar(max)') Blocked_Process_loginname,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@isolationlevel)[1]','nvarchar(max)') Blocked_Process_isolationlevel,
db_name(CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/@currentdb)[1]','nvarchar(max)')) Blocked_process_currentdb,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocked-process/process/inputbuf)[1]','nvarchar(max)') Blocked_Process_inputbuf,


CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@status)[1]','nvarchar(max)') blocking_process_status,  --- move to node value
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@waitresource)[1]','nvarchar(max)') blocking_process_waitresource,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@waittime)[1]','nvarchar(max)') blocking_process_waittime,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@spid)[1]','nvarchar(max)') blocking_process_spid,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@trancount)[1]','nvarchar(max)') blocking_process_trancount,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@lastbatchstarted)[1]','nvarchar(max)') blocking_process_lastbatchstarted,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@lastbatchcompleted)[1]','nvarchar(max)') blocking_process_lastbatchcompleted,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@hostname)[1]','nvarchar(max)') blocking_process_hostname,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@loginname)[1]','nvarchar(max)') blocking_process_loginname,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@isolationlevel)[1]','nvarchar(max)') blocking_process_isolationlevel,
db_name(CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/@currentdb)[1]','nvarchar(max)')) blocking_process_currentdb,
CONVERT(XML, event_Data).value('(event/data/value/blocked-process-report/blocking-process/process/inputbuf)[1]','nvarchar(max)') blocking_process_inputbuf,

CONVERT(XML, event_Data).value('(event/data[@name="lock_mode"]/value)[1]','nvarchar(max)')  AS lock_mode_,
CONVERT(XML, event_Data).value('(event/data[@name="transaction_id"]/value)[1]','nvarchar(max)')  AS transaction_id_,
CONVERT(XML, event_Data).value('(event/data[@name="resource_owner_type"]/value)[1]','nvarchar(max)')  AS resource_owner_type_
FROM sys.fn_xe_file_target_read_file(N'C:\SQLPlanner_dir_Deadlock_detect\SQLPlanner_Deadlock_detection_data*.xel', NULL, NULL, NULL)
where CONVERT(XML, event_Data).value('(event/@name)[1]', 'varchar(50)') = 'blocked_process_report'
--and cast( CONVERT(XML, event_Data).value('(event/@timestamp)[1]', 'datetime2(0)') as date) = cast(getdate() as date)
