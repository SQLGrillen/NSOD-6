--Capture long running query 
--Create extended event definition 
-- Show path from SSMS wizard to create it 

CREATE EVENT SESSION [SQLPlanner_long_queries] ON SERVER 
ADD EVENT sqlserver.rpc_completed(SET collect_statement=(1)
    ACTION(package0.collect_system_time,sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_name,sqlserver.plan_handle,sqlserver.session_id,sqlserver.session_nt_username,sqlserver.sql_text,
	sqlserver.transaction_id,sqlserver.transaction_sequence,sqlserver.tsql_stack,sqlserver.username)
    WHERE ([package0].[greater_than_uint64]([duration],(1000000)) AND ([result]=(2) AND [package0].[greater_than_uint64]([logical_reads],(0)) AND [package0].[greater_than_uint64]([cpu_time],(100))) AND [package0].[equal_boolean]([sqlserver].[is_system],(0)))),
ADD EVENT sqlserver.sql_batch_completed(
    ACTION(package0.collect_system_time,sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_name,sqlserver.plan_handle,sqlserver.session_id,sqlserver.session_nt_username,
	sqlserver.sql_text,sqlserver.transaction_id,sqlserver.transaction_sequence,sqlserver.tsql_stack,sqlserver.username)
    WHERE ([duration]>(1000000) AND [cpu_time]>(100) AND [package0].[equal_boolean]([sqlserver].[is_system],(0)))),
ADD EVENT sqlserver.sql_statement_completed(
    ACTION(package0.collect_system_time,sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_name,sqlserver.plan_handle,sqlserver.session_id,sqlserver.session_nt_username,sqlserver.sql_text,
	sqlserver.transaction_id,sqlserver.transaction_sequence,sqlserver.tsql_stack,sqlserver.username)
    WHERE ([package0].[greater_than_int64]([duration],(1000000)) AND ([package0].[greater_than_uint64]([cpu_time],(100)) AND [package0].[greater_than_uint64]([logical_reads],(0))) AND [sqlserver].[is_system]=(0))) 
ADD TARGET package0.event_file(SET filename=N'C:\SQLPlanner_dir_Deadlock_detect\SQLPlanner_long_queries_test.xel',max_file_size=(100),max_rollover_files=(5))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=10 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=ON)
GO



	EXEC sp_configure 'show advanced options', 1 ;  RECONFIGURE ;  
	/* Enabled the blocked process report */
	EXEC sp_configure 'blocked_process', '5'; RECONFIGURE ;  
	/* Start the Extended Events session */

--capture deadlock and blocks 
CREATE EVENT SESSION [SQLPlanner_Deadlock_blocked_process] ON SERVER 
ADD EVENT sqlserver.blocked_process_report(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_name,sqlserver.sql_text,sqlserver.username)),
ADD EVENT sqlserver.xml_deadlock_report(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_name,sqlserver.sql_text,sqlserver.username)) 
ADD TARGET package0.event_file(SET filename=N'C:\SQLPlanner_dir_Deadlock_detect\SQLPlanner_Deadlock_detection_data_test.xel',max_file_size=(10),max_rollover_files=(4))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=10 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=ON)
GO



	ALTER EVENT SESSION [SQLPlanner_Deadlock_blocked_process] ON SERVER STATE = START; 
	ALTER EVENT SESSION [SQLPlanner_long_queries] ON SERVER STATE = START; 