
--CPU Usage
DECLARE @ticks_ms BIGINT Declare @Minute int = 60 SELECT @ticks_ms = ms_ticks FROM sys.dm_os_sys_info;  
SELECT TOP(@Minute)  dateadd(ms, -1 * (@ticks_ms - [timestamp]), GetDate()) AS EventDateTime   , ProcessUtilization as 'SQLCPU_Usage', 
SystemIdle 'IdleCPU_Usage',100 - SystemIdle - ProcessUtilization AS 'Other_Process_CPU_Percent',getdate() CreateDateTime FROM (SELECT record.value('(./Record/@id)[1]', 'int') AS id, 
    record.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]', 'int') AS SystemIdle, record.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]', 'int') 
    AS ProcessUtilization, TIMESTAMP  FROM (SELECT TIMESTAMP, convert(XML, record) AS record FROM sys.dm_os_ring_buffers WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR' 
    and record LIKE '%SystemHealth%') AS sub1) AS sub2 ORDER BY id DESC 




--disk latency 
SELECT TOP (10) Getdate() _datetime,DB_NAME (a.database_id) AS dbname,
      a.io_stall / NULLIF (a.num_of_reads + a.num_of_writes, 0) AS average_tot_latency,
      Round ((a.size_on_disk_bytes / square (1024.0)), 1) AS size_mb,
      b.physical_name AS [fileName]
   FROM sys.dm_io_virtual_file_stats(NULL, NULL) AS a,
      sys.master_files AS b
   WHERE a.database_id = b.database_id
      AND a.FILE_ID = b.FILE_ID
   ORDER BY average_tot_latency DESC

--Good: < 10ms
--Okay: 10 � 20ms
--Bad: 20 � 50ms
--Seriously bad: > 50ms


--connections per each DB:
SELECT getdate() _datetime,    DB_NAME(dbid) as DBName,    COUNT(dbid) as NumberOfConnections,    loginame as LoginName
FROM    sys.sysprocesses
WHERE  dbid > 0 GROUP BY     dbid, loginame


