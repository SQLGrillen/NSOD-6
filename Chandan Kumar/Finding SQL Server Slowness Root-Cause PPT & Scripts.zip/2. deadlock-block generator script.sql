create table tableA
(id int ,
value varchar(100) )

create table tableB
(id int ,
value varchar(100) )

insert into tableA values (1,'a')
insert into tableA  values (2,'b')

insert into tableB  values (1,'a')
insert into tableB  values (2,'b')


BEGIN TRAN

UPDATE tableA
set [value] = 'C1'
WHERE id = 1

WAITFOR DELAY '00:00:10'

UPDATE tableB
set [value] = 'C2'
WHERE id = 1

--commit

--second query window
BEGIN TRAN

UPDATE tableB
set [value] = 'C2'
WHERE id = 1

WAITFOR DELAY '00:00:10'

UPDATE tableA
set [value] = 'C1'
WHERE id = 1


 